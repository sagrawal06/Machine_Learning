import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd

app = Flask(__name__, static_url_path='/static')
data_ = []
with open("pickle.dat", "rb") as f:
    for _ in range(pickle.load(f)):
        data_.append(pickle.load(f))

label_encoder = data_[0]
std_ = data_[1]
classifier = data_[2]


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''

    dict = {}
    married = request.form.get("teamDropdown")
    dict["Married"] = married

    dependent = request.form.get("teamDropdown1")
    dict["Dependents"] = float(dependent)

    education = request.form.get("teamDropdown2")
    if education =="Graduate":
        dict["Education"] = 1
    else:
        dict["Education"] = 0

    self_employed = request.form.get("teamDropdown6")
    dict["Self_Employed"] = self_employed


    credit_history = request.form.get("teamDropdown9")
    dict["Credit_History"] = float(credit_history)

    property_area = request.form.get("teamDropdown10")
    dict["Property_Area"] = property_area


    self_employed = request.form.get("teamDropdown6")
    dict["Self_Employed"] = self_employed

    int_features = [x for x in request.form.values()]
    dict["ApplicantIncome"] = float(int_features[6])
    dict["CoaPPlication"] = float(int_features[7])
    dict["LoanAmount"] = float(int_features[8])
    dict["Loan_Amount_term"] = float(int_features[9])

    data_frame = pd.DataFrame(dict, index=[0])
    # #Label encoder on testing data

    data_frame["Property_Area"] = label_encoder.fit_transform(data_frame["Property_Area"])


    #Get Dummies on testing data
    data_frame = pd.get_dummies(data_frame, prefix=['Married', 'Self_Employed'], columns=['Married', 'Self_Employed'])
    #print(data_frame.dtypes)

    numeric_list = ["Dependents", "ApplicantIncome", "CoaPPlication", "LoanAmount", "Loan_Amount_term"]
    # numerical_train = data_frame.columns[(data_frame.dtypes == 'float64') | (data_frame.dtypes == 'int64')].tolist()
    data_frame[numeric_list] = std_.transform(data_frame[numeric_list])

    value = classifier.predict(data_frame)
    return render_template('index.html', prediction_text='Predicted loan value is $ {}'.format(value))
    #return jsonify("shriya")

if __name__ == "__main__":
    app.run(debug=True,port=8000)